@echo off

set TTPMACRO="C:\Program Files (x86)\teraterm\ttpmacro.exe"

set COMMANDLIST="%~dp0commandlist\test.txt"
set MACRO="%~dp0macro\Login.ttl"
start "" %TTPMACRO% %MACRO% %COMMANDLIST%

pause
