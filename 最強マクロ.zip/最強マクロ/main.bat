@echo off

set TTPMACRO="C:\Program Files (x86)\teraterm\ttpmacro.exe"

set COMMANDLIST="%~dp0commandlist\�e�X�g.txt"
set MACRO="%~dp0macro\Login.ttl"
start "" %TTPMACRO% %MACRO% %COMMANDLIST%
timeout /t 2

