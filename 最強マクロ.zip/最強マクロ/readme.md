ご説明ありがとうございます。理解しました。以下の前提でREADMEを修正します。

- `Login.ttl` は接続先ごとにコピーして作成する（ホスト情報はTTL側に持つ）
- `main.bat` はあくまで「どのTTLファイル」と「どのコマンドリスト」を組み合わせて実行するかを定義するだけの役割
- 複数機器を扱う場合は、`main.bat` 内の `set COMMANDLIST` から `timeout` までの1ブロックをコピーし、`COMMANDLIST` と `MACRO` を対象機器用に書き換えることで対応する
- サンプルの「同一ホストへの複数コマンドリスト実行」は本質ではなく、あくまでブロックのコピー例として捉える
- `main.txt` は説明用にtxt拡張子にしているだけで、実際は `.bat` として使用する

情報源：ご提供いただいた `main.txt`・`Login.ttl` のソースコード、およびご説明内容のみです（外部情報源なし）。

---

# SSH自動ログイン・コマンド実行ツール

Tera Termマクロ（TTLファイル）とバッチファイルを組み合わせて、複数機器へのSSHログイン・コマンド自動実行・ログ取得を行うための仕組みです。

## 概要

- **`Login.ttl`**：SSH接続・ログイン・（必要に応じて）root昇格やenable昇格・コマンドリスト実行・ログ保存を行うマクロ本体。**接続先ごとにファイルをコピーして作成**します。
- **`main.bat`**：どの `Login.ttl`（＝どの機器）に対して、どのコマンドリストを実行するかを定義し、まとめて起動するためのバッチファイル。

つまり「機器の接続情報」はTTLファイル側に、「どの機器にどのコマンドを実行させるか」はbatファイル側に持つ、という役割分担になっています。

## ファイル構成

```
ログ取得マクロ/
├─ main.bat                      ・・・ 各TTLファイルとコマンドリストを紐づけて起動するバッチファイル
│
├─ macro/
│  ├─ Login_機器A.ttl             ・・・ 機器Aの接続情報を設定したマクロ
│  ├─ Login_機器B.ttl             ・・・ 機器Bの接続情報を設定したマクロ
│  ├─ ...                         ・・・ 接続先ごとに複製して作成
│  └─ logs/                       ・・・ ログ出力先（Login.ttl初回実行時に自動作成）
│     └─ YYYYMMDDHHMMSS_ホスト名.txt
│
└─ commandlist/
   ├─ 機器A_コマンド.txt           ・・・ 機器Aに実行させるコマンドリスト
   ├─ 機器B_コマンド.txt           ・・・ 機器Bに実行させるコマンドリスト
   └─ ...
```

> 上記はイメージです。実際のファイル名は運用に合わせて自由に命名してください。

## 事前設定

### 1. Tera Termのパス（main.bat）

`main.bat` 内の以下の行を、実際のインストールパスに合わせて修正してください。

```bat
set TTPMACRO="C:\Program Files (x86)\teraterm\ttpmacro.exe"
```

### 2. 接続先の作成（Login.ttlのコピー）

接続したい機器の数だけ `Login.ttl` をコピーし、ファイル内の以下の変数を接続先に合わせて書き換えます。

| 変数名 | 説明 |
|---|---|
| `HOSTNAME` | 接続先のホスト名（ログファイル名にも使用） |
| `IPADDR` | 接続先のIPアドレス |
| `USERNAME` | SSHログイン用ユーザー名 |
| `PASSWORD` | SSHログイン用パスワード |
| `ROOT_PASSWORD` | Linuxで`su -`によるroot昇格を行う場合のパスワード。使用しない場合は空欄`''` |
| `ENABLE_PASSWORD` | Ciscoで`enable`によるモード昇格を行う場合のパスワード。使用しない場合は空欄`''` |

> **注意:** `ROOT_PASSWORD` と `ENABLE_PASSWORD` を両方同時に設定するとエラーメッセージが表示され、処理が中断されます。いずれか一方のみ設定してください。

### 3. コマンドリストファイルの作成

`commandlist` フォルダ内に、機器ごとに実行したいコマンドをまとめたテキストファイルを配置します。

- 1行につき1コマンド
- 行頭が `#` の行はコメントとして無視される

```
# これはコメント行
ls -l
df -h
```

## パラメータについて

Tera Termマクロでは `param1` に実行中のマクロファイル名（自身のパス）が予約済みの値として自動的に格納されます。そのため、ユーザーが指定できる実質的な第一引数は **`param2`** です。

`main.bat` では、以下のように `Login.ttl` に対してコマンドリストファイルのパスを渡しています（この引数がTTL内では`param2`として参照されます）。

```bat
start "" %TTPMACRO% %MACRO% %COMMANDLIST%
```

## main.batの仕組みと複数機器への対応方法

`main.bat` は、以下の1ブロックを1機器分の実行単位として構成されています。

```bat
set COMMANDLIST="%~dp0commandlist\コマンドリスト.txt"
set MACRO="%~dp0macro\Login.ttl"
start "" %TTPMACRO% %MACRO% %COMMANDLIST%
timeout /t 2
```

- `COMMANDLIST` … 実行させたいコマンドリストファイルのパス
- `MACRO` … 接続先に応じて作成した `Login.ttl`（コピーしたもの）のパス
- `start` により非同期でTera Termマクロを起動
- `timeout /t 2` で2秒待機してから次のブロックへ進む（同時起動による負荷や競合を避けるための間隔）

### 複数機器のログを取得する場合

**このブロックをまとめてコピーし、`COMMANDLIST` と `MACRO` を対象機器用のファイルパスに書き換えることで、機器数分の処理を追加できます。**

例：機器A・機器Bの2台を対象にする場合

```bat
@echo off

set TTPMACRO="C:\Program Files (x86)\teraterm\ttpmacro.exe"

REM ↓機器Aのブロック
set COMMANDLIST="%~dp0commandlist\機器A_コマンド.txt"
set MACRO="%~dp0macro\Login_機器A.ttl"
start "" %TTPMACRO% %MACRO% %COMMANDLIST%
timeout /t 2

REM ↓機器Bのブロック（コピーしてMACROとCOMMANDLISTを変更）
set COMMANDLIST="%~dp0commandlist\機器B_コマンド.txt"
set MACRO="%~dp0macro\Login_機器B.ttl"
start "" %TTPMACRO% %MACRO% %COMMANDLIST%
timeout /t 2
```

機器を追加する場合は、同様に `set COMMANDLIST` から `timeout /t 2` までの4行をコピーし、`COMMANDLIST` と `MACRO` のファイル名部分だけを対象機器のものに変更すれば、大量の機器に対しても同じ書き方で対応できます。

> 元のサンプル（`main.txt`）で同一ホストに対し2つのコマンドリストを実行している部分は、あくまで「ブロックをコピーして書き換える」という使い方の例であり、同一ホストへの複数コマンドリスト実行自体に特別な意図はありません。

## 実行フロー

```mermaid
flowchart TD
    A[main.bat 実行] --> B[1ブロック目: start ttpmacro Login_機器A.ttl 機器A_コマンド.txt]
    B --> C[2秒待機]
    C --> D[2ブロック目: start ttpmacro Login_機器B.ttl 機器B_コマンド.txt]
    D --> E[2秒待機]
    E --> F[以降、機器数分ブロックが続く]
    F --> G[main.bat 終了]
    B -.非同期起動.-> H[機器A: SSH接続→コマンド実行→ログ保存]
    D -.非同期起動.-> I[機器B: SSH接続→コマンド実行→ログ保存]
```

`start` により各ブロックは非同期（別プロセス）で起動されるため、**それぞれの機器への接続・コマンド実行は並行して進み、`main.bat` はマクロの完了を待たずに終了**します。

## 使い方

1. 接続したい機器の数だけ `Login.ttl` をコピーし、それぞれに接続先情報を設定する
2. 各機器に対応するコマンドリストファイルを `commandlist` フォルダに配置する
3. `main.bat` に、機器数分のブロック（`set COMMANDLIST`〜`timeout /t 2`）を用意し、それぞれ対応する `MACRO` と `COMMANDLIST` を設定する
4. `main.bat` を実行する

```
main.bat
```

## ログについて

- `Login.ttl` の実行ごとに `logs` フォルダへログファイルが自動生成されます。
- ログファイル名は `YYYYMMDDHHMMSS_ホスト名.txt` の形式です（`HOSTNAME`は各TTLファイル内で設定した値）。
- 機器ごとにTTLファイルを分けているため、ログファイル名からどの機器のログかを判別できます。

## エラー時の挙動

| 状況 | 挙動 |
|---|---|
| SSH接続失敗 | メッセージボックス表示後、マクロ終了 |
| `ROOT_PASSWORD`と`ENABLE_PASSWORD`が両方設定されている | メッセージボックス表示後、マクロ終了 |
| 指定したコマンドリストファイルが存在しない | メッセージボックス表示後、マクロ終了 |

## 注意事項

- パスワードが各`Login.ttl`内に平文で記載されるため、ファイルの取り扱い・保管には十分注意してください。
- 機器の台数が多い場合、`main.bat`内のTTLファイル・コマンドリストファイルも同数用意する必要があります。命名規則を揃えておくと管理しやすくなります。
- `start`による非同期起動のため、`main.bat`実行後は各Tera Termウィンドウの状態や`logs`フォルダの出力で完了を確認してください。